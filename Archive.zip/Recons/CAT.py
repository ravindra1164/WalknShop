import multiprocessing
from ReconRules import MissingRecords


def main(recon_id, list_id, exception_type, key, jobnm, orig_recon_id, orig_list_id, media, clearing, secondory,
         part_name, odate, sub_list_id):
    task_order = [
            ["MissingRecords", "DuplicateRecords"],
            ["MissingRecords", "DuplicateRecords"]
    ]

    for parallel_tasks in task_order:
        jobs = []
        for rule in parallel_tasks:
            p = multiprocessing.Process(
                target=eval(
                    rule + '.main' + '("' +
                    recon_id + '", "' +
                    list_id + '", "' +
                    exception_type + '", "' +
                    key + '", "' +
                    jobnm + '", "' +
                    orig_recon_id + '", "' +
                    orig_list_id + '", "' +
                    media + '", "' +
                    clearing + '", "' +
                    secondory + '", "' +
                    part_name + '", "' +
                    odate + '", "' +
                    '")'))
            jobs.append(p)
            p.start()

        for job in jobs:
            job.join()
