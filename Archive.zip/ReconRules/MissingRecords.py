from DBConnector import SnowflakeConnector
from Utils import TrackingReconRules

sf_database = "RRWS"
sf_track_table = "rekon_tracking"
sf_rulename = "Missing_Record"


def main(recon_id, list_id, exception_type, key, jobnm, orig_recon_id, orig_list_id, media, clearing, secondory,
         part_name, odate, sub_list_id):
    sfq, sf_connection = SnowflakeConnector.create_sf_connection()

    past_runs = TrackingReconRules.get_past_runs(sfq, sf_database, sf_track_table, recon_id, odate, sf_rulename)

    if past_runs:
        print("Past Success run exits for Missing Record for recon {0} for odate {1}".format(recon_id, odate))
    else:
        try:
            TrackingReconRules.start_run(sfq, sf_database, sf_track_table, recon_id, odate, sf_rulename)
            run_rule(recon_id, list_id, exception_type, key, jobnm, orig_recon_id, orig_list_id, media, clearing,
                     secondory,
                     part_name, odate, sub_list_id, sfq)
            TrackingReconRules.end_run(sfq, sf_database, sf_track_table, recon_id, odate, sf_rulename, "SUCCESS")
        except:
            TrackingReconRules.end_run(sfq, sf_database, sf_track_table, recon_id, odate, sf_rulename, "Failed")
            print("Missing Record Rule Failed.")

    SnowflakeConnector.close_sf_connection(sfq, sf_connection)


def run_rule(recon_id, list_id, exception_type, key, jobnm, orig_recon_id, orig_list_id, media, clearing, secondory,
             part_name, odate, sub_list_id, sfq):
    rule_meta_data = get_meta_data(recon_id, list_id, exception_type, sfq)
    rule_sql = ""
    for RECON_ID, LIST_ID, ACTIVE_IND in rule_meta_data:
        if ACTIVE_IND == 'Y':
            if (RECON_ID == 'MUNICIPAL_SEC_TRADES' or RECON_ID == 'ASOF_PROCESS') and LIST_ID == 'PNS_RTRS':
                rule_sql.append("INSERT INTO")
    sfq.execute(rule_sql)


def get_meta_data(recon_id, list_id, exception_type, sfq):
    meta_query = "SELECT DISTINCT S.RECON_ID, S.LIST_ID, S.ACTIVE_IND" \
                 "FROM ORD_COMP.T_RRWS_RULE_SETTINGS s" \
                 "  INNER JOIN ORD_COMP.RRWS_RULE_EXCLUSIONS E ON S.RECON_ID = E.RECON_ID" \
                 "WHERE S.RECON_ID = {0} AND S.LIST_ID = {1} AND S.RULE_CATEGORY='MR' AND S.EXCEPTION_TY_C = {2}" \
                 "ORDER BY EXCEPTION_TY_C ASC".format(recon_id, list_id, exception_type)
    return sfq.execute(meta_query)
