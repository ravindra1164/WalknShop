import unittest
from Recons import CAT

class MyTestCase(unittest.TestCase):
    def recon_test(self):
        CAT.main(123)
        self.assertEqual(True, False)  # add assertion here


if __name__ == '__main__':
    unittest.main()
