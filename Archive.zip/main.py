import sys
import Recons.CAT
import Recons.ACT


def print_hi(name):
    # Use a breakpoint in the code line below to debug your script.
    print(f'Hi, {name}')  # Press ⌘F8 to toggle the breakpoint.


def main():
    if recon_id == "123":
        Recons.CAT.main(recon_id, list_id, exception_type, key, jobnm, orig_recon_id, orig_list_id, media, clearing, secondory, part_name, odate, sub_list_id)
    elif recon_id == 321:
        Recons.ACT.main(recon_id)
    else:
        print('Missing recon. Please check input parameters')


if __name__ == '__main__':
    global recon_id, list_id, exception_type, key, jobnm, orig_recon_id, orig_list_id, media, clearing, secondory, part_name, odate, sub_list_id

    recon_id = sys.argv[1]
    list_id = sys.argv[2]
    exception_type = sys.argv[3]
    key = sys.argv[4]
    jobnm = sys.argv[5]
    orig_recon_id = sys.argv[6]
    orig_list_id = sys.argv[7]
    media = sys.argv[8]
    clearing = sys.argv[9]
    secondory = sys.argv[10]
    part_name = sys.argv[11]
    odate = sys.argv[12]
    sub_list_id = sys.argv[13]

    main()
