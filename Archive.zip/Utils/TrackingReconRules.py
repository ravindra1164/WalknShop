def get_past_runs(sfq, sf_database, sf_track_table, recon_id, odate, sf_rulename):
    if len(sfq.execute(
            "SELECT * FROM {0}.{1} WHERE recon_id = '{2}' and rule_name = '{3}' and odate = '{4}' and status = "
            "'SUCCESS' "
                    .format(sf_database, sf_track_table, recon_id, sf_rulename, odate))) > 0:
        return True
    else:
        return False


def start_run(sfq, sf_database, sf_track_table, recon_id, odate, sf_rulename):
    try:
        sfq.execute("INSERT INTO {0}.{1}(recon_id, rulename, odate, status) VALUES('{2}', '{3}', '{4}', 'RUNNING')"
                    .format(sf_database, sf_track_table, recon_id, sf_rulename, odate))
    except:
        print("Failed to insert tracking row into DB")


def end_run(sfq, sf_database, sf_track_table, recon_id, odate, sf_rulename, sf_status):
    try:
        sfq.execute("UPDATE {0}.{1} SET status = '{2}' WHERE recon_id = '{3}' and rule_name = '{4}' and odate = '{5}'"
                    .format(sf_database, sf_track_table, sf_status, recon_id, sf_rulename, odate))
    except:
        print("Failed to update tracking row into DB")
