import snowflake.connector as sf


def create_sf_connection(
        sf_password='TestPass',
        sf_account='TestAccount',
        sf_user='TestUser',
        sf_database='TestDB'
):
    if sf_password == '':
        import getpass
        sf_password = getpass.getpass('Password:')
    try:
        sf_connection = sf.connect(
            user=sf_user,
            password=sf_password,
            account=sf_account
        )
        sfq = sf_connection.cursor()

        return sfq, sf_connection

    except:
        print('Connection failed. Check credentials')


def close_sf_connection(
        sfq,
        sf_connection
):
    sfq.close()
    sf_connection.close()
