import oracledb as ord


def create_ord_connection(
        ord_password='TestPass',
        ord_dsn='TestAccount',
        ord_user='TestUser',
        ord_database='TestDB'
):
    if ord_password == '':
        import getpass
        ord_password = getpass.getpass('Password:')
        # Test the connection to Snowflake
    try:
        ord_connection = ord.connect(
            user=ord_user,
            password=ord_password,
            dsn=ord_dsn
        )

        return ord_connection

    except:
        print('Connection failed. Check credentials')


def close_ord_connection(
        ord_connection
):
    ord_connection.close()
